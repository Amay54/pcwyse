'use client';
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bot, Sparkles, X, Send } from 'lucide-react';

export default function AIChatbot() {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="fixed bottom-8 right-8 z-50">
      <AnimatePresence>
        {isOpen && (
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="mb-4 w-80 h-96 bg-white rounded-[32px] shadow-2xl border flex flex-col overflow-hidden">
            <div className="p-4 bg-blue-600 text-white flex justify-between">
              <div className="flex items-center gap-2 font-bold"><Bot /> PCWyse AI</div>
              <X onClick={() => setIsOpen(false)} className="cursor-pointer" />
            </div>
            <div className="flex-1 p-4 text-sm text-slate-600">How can I help you diagnose your PC today?</div>
            <div className="p-4 border-t"><input className="w-full bg-slate-50 p-2 rounded-xl text-sm" placeholder="Type here..." /></div>
          </motion.div>
        )}
      </AnimatePresence>
      <button onClick={() => setIsOpen(!isOpen)} className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center shadow-xl">
        <Sparkles />
      </button>
    </div>
  );
}