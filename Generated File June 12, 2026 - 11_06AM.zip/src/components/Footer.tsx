import { ShieldCheck } from 'lucide-react';
export default function Footer() {
  return (
    <footer className="bg-slate-900 text-white py-12 px-6">
      <div className="container mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold">P</div>
          <span className="font-bold">PCWyse</span>
        </div>
        <div className="text-slate-500 text-sm">© 2024 PCWyse Technologies Pvt Ltd. Smart Services. Simplified.</div>
        <div className="flex gap-4 opacity-50 text-xs">
          <span>Privacy</span>
          <span>Terms</span>
          <span>Warranty</span>
        </div>
      </div>
    </footer>
  );
}