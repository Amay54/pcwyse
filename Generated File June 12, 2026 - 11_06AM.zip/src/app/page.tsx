import Hero from '@/components/Hero';
import AIChatbot from '@/components/AIChatbot';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <main className="min-h-screen">
      <Hero />
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6 text-center">
            <h2 className="text-3xl font-bold mb-4">Trusted by 10,000+ Customers</h2>
            <div className="flex justify-center gap-8 opacity-50">
                <span>Genuine Parts</span>
                <span>Verified Techs</span>
                <span>90 Min Response</span>
            </div>
        </div>
      </section>
      <AIChatbot />
      <Footer />
    </main>
  );
}