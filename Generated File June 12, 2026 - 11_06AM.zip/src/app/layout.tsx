import './globals.css'
import { Inter } from 'next/font/google'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'PCWyse | Smart Services. Simplified.',
  description: 'Professional Laptop & PC Repair at Your Doorstep',
}

export default function RootLayout({
  children,
}: {
  children: React.React_node
}) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  )
}